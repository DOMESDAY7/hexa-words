# hexa-words
Le projet hexa#words a été créé dans le cadre du DUT MMI par l’enseignante Gaëlle Charpentier. L’aboutissement de ce projet est de créer un site alliant un mot et une couleur. Le mot en question étant l’homologue hexadécimal pour la couleur.

The hexa#words project was created in the framework of the DUT MMI by the teacher Gaëlle Charpentier. The result of this project is to create a website combining a word and a color. The word in question is the hexadecimal counterpart for the color.
