<?php
try{
    $link = new PDO('mysql:host=wi0d3.myd.infomaniak.com;dbname=wi0d3_idiots', 'wi0d3_mathieu', 'TFXf_bLzcN2', array
    (PDO::MYSQL_ATTR_INIT_COMMAND => "SET NAMES utf8mb4")); 

}catch(Exception $e){
    die("Erreur:".$e->getMessage());
}