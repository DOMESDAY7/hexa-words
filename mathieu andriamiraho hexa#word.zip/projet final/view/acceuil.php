<body>
    <main class="content">
        <h1 class="unselect">We are</h1>
        <section class="content_titre">
            <h1 class="titreIdiot unselect">
                <span class="letter">I</span>
                <span class="letter">d</span>
                <span class="letter">i</span>
                <span class="letter">o</span>
                <span class="letter">t</span>
                <span class="letter">s</span>
            </h1>
            
        </section>
        <section class="content_button">
            <a href="?page=choice" class="button link1 unselect">Tell my idiocy</a><br>
            <a href="?page=see" class="button link2 unselect">See the others idiots</a>
        </section>
    </main>
    <footer>
        <a href="?page=aboutUs" class="about unselect">About us</a>
    </footer>
    <script src="./public/js/acceuil.js"></script>
</body>

</html>